package com.yudhistiroagung.mockva.presentation.ui.transfer_success

import com.yudhistiroagung.mockva.R
import com.yudhistiroagung.mockva.presentation.common.base.BaseFragment

class TransferSuccessFragment : BaseFragment() {

    override fun getResLayoutId(): Int = R.layout.fragment_transfer_success

}