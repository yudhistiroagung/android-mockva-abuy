package com.yudhistiroagung.mockva.presentation.ui.history

import com.yudhistiroagung.mockva.R
import com.yudhistiroagung.mockva.presentation.common.base.BaseFragment

class HistoryFragment : BaseFragment() {

    override fun getResLayoutId(): Int = R.layout.fragment_history

}