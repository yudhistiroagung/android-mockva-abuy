package com.yudhistiroagung.mockva.domain.authentication.model

data class LoginRequest(val username: String, val password: String)