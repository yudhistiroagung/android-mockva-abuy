package com.yudhistiroagung.mockva.presentation.ui.transfer_confirmation

import com.yudhistiroagung.mockva.R
import com.yudhistiroagung.mockva.presentation.common.base.BaseFragment

class TransferConfirmationFragment : BaseFragment() {

    override fun getResLayoutId(): Int = R.layout.fragment_transfer_confirmation

}