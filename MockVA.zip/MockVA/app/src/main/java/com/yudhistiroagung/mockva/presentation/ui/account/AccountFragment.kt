package com.yudhistiroagung.mockva.presentation.ui.account

import com.yudhistiroagung.mockva.R
import com.yudhistiroagung.mockva.presentation.common.base.BaseFragment

class AccountFragment: BaseFragment() {

    override fun getResLayoutId(): Int = R.layout.fragment_account

}