package com.yudhistiroagung.mockva.domain.authentication.model

data class LoginData(val sessionId: String, val accountId: String)
